﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    public static class DataSettings
    {
        public const string DefaultConnection = "Server=.\\SQLEXPRESS;Database=StudentSystemCodeFirst;Integrated Security=true";
    }
}
