﻿namespace MusicHub.DataProcessor.ExportDtos
{
    public class ExportSongFromAlbumDTO
    {
        public string SongName { get; set; }

        public string Price { get; set; }

        public string Writer { get; set; }
    }
}
