﻿namespace VaporStore.DataProcessor
{
    using System;
    using System.Linq;
    using Data;
    using Newtonsoft.Json;

    public static class Serializer
    {
        public static string ExportGamesByGenres(VaporStoreDbContext context, string[] genreNames)
        {
            var genre = context
                .Genres
                .Where(g => genreNames.Contains(g.Name))
                .Where(g => g.Games.Any(game => game.Purchases.Count >= 1))
                .Select(g => new
                {
                    Id = g.Id,
                    Genre = g.Name,
                    Games = g.Games.Where(game => game.Purchases.Count() >= 1).Select(game => new
                    {
                        Id = game.Id,
                        Title = game.Name,
                        Developer = game.Developer.Name,
                        Tags = string.Join(", ", game.GameTags.Select(gt => gt.Tag.Name)),
                        Players = game.Purchases.Count()
                    })
                    .OrderByDescending(game => game.Players)
                    .ThenBy(game => game.Id),
                    TotalPlayers = g.Games.Where(tp => tp.Purchases.Any())
                                            .Sum(game => game.Purchases.Count)
                })
                .OrderByDescending(g => g.TotalPlayers)
                .ThenBy(g => g.Id)
                .ToList();

            var output = JsonConvert.SerializeObject(genre, Formatting.Indented);

            return output;
        }

        public static string ExportUserPurchasesByType(VaporStoreDbContext context, string storeType)
        {
            throw new NotImplementedException();
        }
    }
}