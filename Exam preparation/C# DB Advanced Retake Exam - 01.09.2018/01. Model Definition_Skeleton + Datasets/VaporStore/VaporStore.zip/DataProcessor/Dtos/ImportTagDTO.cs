﻿namespace VaporStore.DataProcessor.Dtos
{
    public class ImportTagDTO
    {
        public string Name { get; set; }
    }
}
