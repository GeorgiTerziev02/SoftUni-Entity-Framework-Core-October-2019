﻿namespace VaporStore.Data.Models.Enumerations
{//•	Type – enumeration of type CardType, with possible values(“Debit”, “Credit”) (required)

    public enum CardType
    {
        Debit = 0,
        Credit = 1
    }
}
