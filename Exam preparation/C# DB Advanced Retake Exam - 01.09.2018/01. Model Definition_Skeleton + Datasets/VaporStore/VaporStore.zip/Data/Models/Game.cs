﻿namespace VaporStore.Data.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

	public class Game
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Range(0,double.MaxValue), Required]
        public decimal Price { get; set; }

        [Required]
        public DateTime ReleaseDate { get; set; }

        [Required]
        public int DeveloperId { get; set; }

        public Developer Developer { get; set; }

        [Required]
        public int GenreId { get; set; }

        public Genre Genre { get; set; }

        public ICollection<Purchase> Purchases { get; set; } = new HashSet<Purchase>();

        [MinLength(1)]
        public ICollection<GameTag> GameTags { get; set; } = new HashSet<GameTag>();
                                           //•	Id – integer, Primary Key
                                           //•	Name – text(required)
                                           //•	Price – decimal (non-negative, minimum value: 0) (required)
                                           //•	ReleaseDate – Date(required)
                                           //•	DeveloperId – integer, foreign key(required)
                                           //•	Developer – the game’s developer(required)
                                           //•	GenreId – integer, foreign key(required)
                                           //•	Genre – the game’s genre(required)
                                           //•	Purchases - collection of type Purchase
                                           //•	GameTags - collection of type GameTag.Each game must have at least one tag.
    }
}
