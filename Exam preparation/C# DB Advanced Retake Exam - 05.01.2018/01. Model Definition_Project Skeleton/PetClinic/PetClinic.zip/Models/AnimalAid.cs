﻿namespace PetClinic.Models
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class AnimalAid
    {
        //        -	Id – integer, Primary Key
        //-	Name – text with min length 3 and max length 30 (required, unique)
        //-	Price – decimal (non-negative, minimum value: 0.01, required)
        //-	AnimalAidProcedures – collection of type ProcedureAnimalAid

        [Key]
        public int Id { get; set; }

        //TODO:ADD unique
        [MinLength(3), MaxLength(30), Required]
        public string Name { get; set; }

        [Required, Range(0.01, double.MaxValue)]
        public decimal Price { get; set; }

        public ICollection<ProcedureAnimalAid> AnimalAidProcedures { get; set; } = new HashSet<ProcedureAnimalAid>();
    }
}
